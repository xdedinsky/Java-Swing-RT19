package sk.stuba.fei.uim.oop.window;

import lombok.Getter;
import lombok.Setter;
import sk.stuba.fei.uim.oop.logic.MyActionListener;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class MyMenu extends JPanel {
    private static final String PLUS_BUTTON = "Plus";
    private static final String LINE_BUTTON = "Line";
    private static final String CHOICE_BUTTON = "Choice";
    private static final String RED_COLOR = "Red";
    private static final String BLUE_COLOR = "Blue";
    private static final String GREEN_COLOR = "Green";
    private static final String YELLOW_COLOR = "Yellow";

    @Getter @Setter
    private JPanel colorPanel;
    private JComboBox<String> colorsBox;
    @Getter
    private ArrayList<Color> colors;
    @Getter @Setter
    private Color currentColor;
    @Getter @Setter
    private int mode;

    public MyMenu() {
        this.setLayout(new GridLayout(1, 5));
        this.setVisible(true);
        this.setOpaque(true);
        MyActionListener myActionListener = new MyActionListener(this);

        this.colors = new ArrayList<>();
        colors.add(Color.RED);
        colors.add(Color.BLUE);
        colors.add(Color.GREEN);
        colors.add(Color.YELLOW);
        mode = 0;
        colorPanel = new JPanel();
        colorsBox = new JComboBox<>();
        colorsBox.addActionListener(myActionListener);
        colorsBox.addItem(RED_COLOR);
        colorsBox.addItem(BLUE_COLOR);
        colorsBox.addItem(GREEN_COLOR);
        colorsBox.addItem(YELLOW_COLOR);
        currentColor = colors.get(0);
        JButton plus = new JButton(PLUS_BUTTON);
        plus.addActionListener(myActionListener);
        JButton line = new JButton(LINE_BUTTON);
        line.addActionListener(myActionListener);
        JButton choice = new JButton(CHOICE_BUTTON);
        choice.addActionListener(myActionListener);

        colorPanel.setBackground(colors.get(0));

        this.add(plus);
        this.add(line);
        this.add(choice);
        this.add(colorsBox);
        this.add(colorPanel);

        this.setVisible(true);
        this.revalidate();
        this.repaint();
    }

    public JComboBox<String> getColorsBox() {
        return colorsBox;
    }
}