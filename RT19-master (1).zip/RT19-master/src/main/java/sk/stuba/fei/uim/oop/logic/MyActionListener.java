package sk.stuba.fei.uim.oop.logic;

import sk.stuba.fei.uim.oop.window.MyMenu;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MyActionListener implements ActionListener {
    private MyMenu menu;

    public MyActionListener(MyMenu menu) {
        this.menu = menu;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()) {
            case "Plus":
                menu.setMode(0);
                break;
            case "Line":
                menu.setMode(1);
                break;
            case "Choice":
                menu.setMode(2);
                break;
            default:
                String selectedColor = (String) menu.getColorsBox().getSelectedItem();
                switch (selectedColor) {
                    case "Red":
                        menu.getColorPanel().setBackground(Color.RED);
                        menu.setCurrentColor(Color.RED);
                        menu.setBackground(Color.RED);
                        break;
                    case "Green":
                        menu.getColorPanel().setBackground(Color.GREEN);
                        menu.setCurrentColor(Color.GREEN);
                        menu.setBackground(Color.GREEN);
                        break;
                    case "Blue":
                        menu.getColorPanel().setBackground(Color.BLUE);
                        menu.setCurrentColor(Color.BLUE);
                        menu.setBackground(Color.BLUE);
                        break;
                    case "Yellow":
                        menu.getColorPanel().setBackground(Color.YELLOW);
                        menu.setCurrentColor(Color.YELLOW);
                        menu.setBackground(Color.YELLOW);
                        break;
                }
                break;
        }
    }
}