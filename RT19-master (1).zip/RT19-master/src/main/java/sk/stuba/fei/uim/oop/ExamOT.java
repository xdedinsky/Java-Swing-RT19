package sk.stuba.fei.uim.oop;

import sk.stuba.fei.uim.oop.window.MyFrame;

public class ExamOT {
    public static void main(String[] args) {
        new MyFrame();
    }
}
