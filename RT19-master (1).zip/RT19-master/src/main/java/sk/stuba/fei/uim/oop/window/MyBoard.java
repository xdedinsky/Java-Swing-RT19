package sk.stuba.fei.uim.oop.window;

import lombok.Getter;
import lombok.Setter;
import sk.stuba.fei.uim.oop.items.Line;
import sk.stuba.fei.uim.oop.items.Plus;
import sk.stuba.fei.uim.oop.logic.MyMouseListener;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class MyBoard extends JPanel {
    @Getter@Setter
    private ArrayList<Line> lines;
    @Getter@Setter
    private ArrayList<Plus> pluses;
    public MyBoard(MyMenu menu) {
        new Dimension(500,500);
        this.lines = new ArrayList<>();
        this.pluses = new ArrayList<>();
        this.setVisible(true);
        this.setOpaque(true);
        this.setBackground(Color.black);
        MyMouseListener mouseListener = new MyMouseListener(menu,this);
        addMouseListener(mouseListener);
        addMouseMotionListener(mouseListener);
        revalidate();
        repaint();
    }

    @Override
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        for (Line line : lines) {
            line.paint(g);
        }
        for (Plus plus : pluses) {
            plus.paint(g);
        }
        this.revalidate();
        this.repaint();
    }
}
