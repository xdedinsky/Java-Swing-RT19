package sk.stuba.fei.uim.oop.window;

import javax.swing.*;
import java.awt.*;

public class MyFrame {
    public MyFrame(){
        JFrame frame = new JFrame();
        frame.setSize(700,700);
        frame.setLayout(new BorderLayout());
        frame.setResizable(false);
        frame.setVisible(true);

        MyMenu menu = new MyMenu();
        frame.add(menu, BorderLayout.NORTH);
        frame.setBackground(Color.PINK);

        MyBoard board = new MyBoard(menu);
        frame.add(board, BorderLayout.CENTER);

        frame.revalidate();
        frame.repaint();
    }
}
