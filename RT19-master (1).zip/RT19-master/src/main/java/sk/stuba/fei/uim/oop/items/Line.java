package sk.stuba.fei.uim.oop.items;

import lombok.Getter;
import lombok.Setter;

import java.awt.*;
@Getter@Setter
public class Line {
    private int x;
    private int y;
    private int width;
    private int height;
    private Color color;
    private boolean dragging;

    public Line(int x, int y, int width, int height, Color color, boolean dragging) {
        this.x = x;
        this.y = y;
        this.width = width/2;
        this.height = height/2;
        this.color = color;
        this.dragging = dragging;
    }

    public void paint(Graphics g) {
        g.setColor(this.color);
        int x1=x,y1=y,x2=width,y2=height;
        if (width < 0){
            x1 = x + width;
            x2 = -width;
        }
        if (height < 0){
            y1 = y + height;
            y2 = -height;
        }
        g.fillRect(x1,y1,x2,y2);
        if (!dragging){
            x = x1;
            y = y1;
            width = x2;
            height = y2;
        }
    }

    public boolean isClicked(int x, int y) {
        return x >= this.x && x <= this.x + this.width && y >= this.y && y <= this.y + this.height;
    }
}
