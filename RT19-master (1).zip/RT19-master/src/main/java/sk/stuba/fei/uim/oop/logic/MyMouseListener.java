package sk.stuba.fei.uim.oop.logic;

import sk.stuba.fei.uim.oop.items.Line;
import sk.stuba.fei.uim.oop.items.Plus;
import sk.stuba.fei.uim.oop.window.MyBoard;
import sk.stuba.fei.uim.oop.window.MyMenu;

import java.awt.event.*;

public class MyMouseListener implements MouseListener, MouseMotionListener {
    private MyMenu menu;
    private MyBoard board;
    private Plus currentPlus;
    private Line currentLine;

    public MyMouseListener(MyMenu menu, MyBoard board) {
        this.menu = menu;
        this.board = board;
    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {
        currentPlus = null;
        currentLine = null;
        switch (menu.getMode()) {
            case 0:
                currentPlus = new Plus(e.getX(), e.getY(),0, 0, menu.getCurrentColor(),true);
                board.getPluses().add(currentPlus);
                board.paintComponent(board.getGraphics());
                break;
            case 1:
                currentLine = new Line(e.getX(), e.getY(),0, 0, menu.getCurrentColor(),true);
                board.getLines().add(currentLine);
                board.paintComponent(board.getGraphics());
                break;
            case 2:
                for (Plus plus : board.getPluses()) {
                    if (plus.isClicked(e.getX(), e.getY())) {
                        currentPlus = plus;
                        if (currentPlus.getColor() != menu.getCurrentColor()) {
                            currentPlus.setColor(menu.getCurrentColor());
                            board.paintComponent(board.getGraphics());
                        }
                        return;
                    }
                }
                for (Line line : board.getLines()) {
                    if (line.isClicked(e.getX(), e.getY())) {
                        currentLine = line;
                        if (currentLine.getColor() != menu.getCurrentColor()) {
                            currentLine.setColor(menu.getCurrentColor());
                            board.paintComponent(board.getGraphics());
                        }
                        return;
                    }
                }
                break;
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if (currentPlus != null) currentPlus.setDragging(false);
        if (currentLine != null) currentLine.setDragging(false);
    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void mouseDragged(MouseEvent e) {
        if (currentPlus != null) {
            if (currentPlus.getColor() != menu.getCurrentColor()) {
                currentPlus.setColor(menu.getCurrentColor());
                board.paintComponent(board.getGraphics());
            }
        }
        if (currentLine != null) {
            if (currentLine.getColor() != menu.getCurrentColor()) {
                currentLine.setColor(menu.getCurrentColor());
                board.paintComponent(board.getGraphics());
            }
        }
        if (menu.getMode() == 2) {
            if (currentLine != null) {
                currentLine.setX(e.getX());
                currentLine.setY(e.getY());
                board.paintComponent(board.getGraphics());
            }
            if (currentPlus != null) {
                currentPlus.setX(e.getX());
                currentPlus.setY(e.getY());
                board.paintComponent(board.getGraphics());
            }
        }
        if (menu.getMode()==0 || menu.getMode()==1) {
            if (currentLine != null) {
                currentLine.setWidth(e.getX() - currentLine.getX());
                currentLine.setHeight(e.getY() - currentLine.getY());
                board.paintComponent(board.getGraphics());
            }
            if (currentPlus != null) {
                currentPlus.setWidth(e.getX() - currentPlus.getX());
                currentPlus.setHeight(e.getY() - currentPlus.getY());
                board.paintComponent(board.getGraphics());
            }
        }
    }

    @Override
    public void mouseMoved(MouseEvent e) {

    }
}
